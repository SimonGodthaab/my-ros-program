from .easy_node import EasyNode
