# parameters of the calibration board
BOARD_WIDTH = 7
BOARD_HEIGHT = 5
SQUARE_SIZE = 0.031
X_OFFSET = 0.191
Y_OFFSET = 0.093
